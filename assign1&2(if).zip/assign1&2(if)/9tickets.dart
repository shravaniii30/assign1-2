void main() {
  int x = 1;
  switch (x) {
    case 1:
      print("price: 2000. Please pay 2000rs");
    case 2:
      print("price: 3000. Please pay 3000rs");
    case 3:
      print("price: 7000. Please pay 7000rs");
    default:
      print("price: 2500. Please pay 2500rs");
  }
}
