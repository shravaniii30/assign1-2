void main() {
  var x = 10;
  if (x < 5) {
    print("$x is less than 5");
  } else if (x > 5) {
    print("$x greater than 5 ");
  } else {
    print("$x is equal to 5");
  }
}
