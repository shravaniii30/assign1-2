void main() {
  int x = 20;
  if (x >= 16 && x % 2 == 0) {
    print("$x is correct ");
  } else {
    print("$x is incorrect number");
  }
}
