void main() {
  int persons = 8;
  if (persons < 8) {
    print("you can enter the lift");
  } else {
    print("you cannot enter the lift");
  }
}
