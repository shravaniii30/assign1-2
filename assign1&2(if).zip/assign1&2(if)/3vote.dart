void main() {
  int age = 10;
  if (age>= 18) {
    print("user can vote");
  } else {
    print("user cannot vote");
  }
}
