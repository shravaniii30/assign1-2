void main() {
  int x = 31;
  if (x >= 30 && x <= 50) {
    print("$x is in correct range");
  } else {
    print("invalid number");
  }
}
