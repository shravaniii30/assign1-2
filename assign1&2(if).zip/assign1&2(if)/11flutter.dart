void main() {
  int ramSize = 8;
  if (ramSize == 4) {
    print("Cant run a project");
  } else if (ramSize == 8) {
    print("Can run a project");
  } else {
    print("invalid input");
  }
}
