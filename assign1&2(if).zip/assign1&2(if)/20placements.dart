void main() {
  int percentage12th = 90;
  num cgpa = 9.5;
  if (percentage12th >= 70 && cgpa >= 7.0 && percentage12th<=100 && cgpa<=10) {
    print("You are eligible for campus placements");
  } else {
    print("You are not eligible for camous placements");
  }
}
