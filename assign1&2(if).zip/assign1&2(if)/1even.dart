void main() {
  var x = 13;
  if (x % 2 == 0) {
    print("$x is even number");
  } else {
    print("$x is odd number");
  }
}
