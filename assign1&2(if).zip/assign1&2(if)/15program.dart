void main() {
  int x = 40;
  if (x % 3 < 2) {
    print("remainder less than two");
  } else if (x % 3 > 2) {
    print("remainder greater than two");
  } else if (x % 3 == 2) {
    print("remainder equal to two");
  } //else {
    //print("remainder not equal to zero");
  //}
}
