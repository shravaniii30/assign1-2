void main() {
  var x = 0;
  if (x > 0) {
    print("$x is positive");
  } else if (x < 0) {
    print("$x is negative");
  } else if (x == 0) {
    print("$x is neither positive nor negative");
  }
}
