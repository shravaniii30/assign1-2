void main() {
  String vehicle = "scooter";
  if (vehicle == "bike") {
    print("Go to parking 2");
  } else if (vehicle == "scooter") {
    print("Go to parking 1");
  } else {
    print("invalid input");
  }
}
